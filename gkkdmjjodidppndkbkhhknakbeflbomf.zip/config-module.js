export const API_URL = "https://api.selectext.app";
export const WEBSITE_URL = "https://selectext.app";
export const BROWSER_TYPE = "chrome";
export const WEB_STORE_URL = "https://chrome.google.com/webstore/detail/selectext-copy-text-from/gkkdmjjodidppndkbkhhknakbeflbomf";